package com.devi;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface Userrepo  extends JpaRepository<User,Integer>{

	@Query("select u from User u where u.user_name=?1")
	public User findbyname(String user_name);

	




	

	
}






	




	














		




	

	



