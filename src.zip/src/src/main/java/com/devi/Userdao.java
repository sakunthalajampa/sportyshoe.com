package com.devi;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class Userdao {

	@Autowired
	Userrepo u_repo;
	
	//USER-INSERTION-CODE
	public User us_reg(User u)
	{
		return u_repo.save(u);
	}
	
	//GET-REGISTERED-UER'S-LIST
	public List<User> user_get()
	{
		return u_repo.findAll();
	}
	
	
	
	
}
