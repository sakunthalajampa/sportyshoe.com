package com.devi;

import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;




@Controller
public class AllController {
	
	
	//* here we have repository/ DB objs  *///
	
	
	@Autowired
	Userrepo userrepo;
	
	@Autowired
	Adminrepo ad_repo;
	

	@Autowired
	ProductRepo pro_repo;
	
	@Autowired
	CartRepo c_repo;
	
	
	//* here we have DAO'S OBJS  *//
	
	@Autowired                             
	Admindao ad_dao;
	
	
	@Autowired
	ProductDao pro_dao;
	
	@Autowired
	CartDao c_dao;
	
	@Autowired
	Userdao u_dao;
	
	
	Logger log=Logger.getAnonymousLogger();


//RestTemplate rest=new RestTemplate();
	@ResponseBody
@RequestMapping("/user_insert")
public String user_insert(HttpServletRequest req,HttpServletResponse res) { 
	
	
   log.info("Enterd into ss login with the request as registration..");

   User u=new User();
   u.setUser_name(req.getParameter("user_name"));
   u.setPass(req.getParameter("pass"));
   u.setEmail(req.getParameter("email"));
 
   User ss = u_dao.us_reg(u);
   System.out.println(ss.getPass());
   if(ss!=null) {
	  
	 return "user_reg_sucees.jsp";
   }
   
return "check details";
 
}
//USER LOGIN USING THIS CODE
	@ResponseBody
	@RequestMapping("/login")
	public String login(HttpServletRequest req, HttpServletResponse res)
	{
		String user_name = req.getParameter("user_name");
		String pass = req.getParameter("pass");
		
		if(userrepo.findbyname(user_name)!=null)
		{
			return "Welcome Back"+ user_name;
		}
		else 
		{
			return "Check Credentisl's or Register";
		}		
	}


/*USER CAN REGISTER USING THIS CODE
	@ResponseBody
	@RequestMapping("/user_insert")
	public ModelAndView user_insert(HttpServletRequest req, HttpServletResponse res)
	{
		ModelAndView mv = new ModelAndView();
		User u = new User();
		u.setUser(req.getParameter("user_fname"));
		u.setUser(req.getParameter("user_lname"));
		u.setUser(req.getParameter("user_phone"));
		u.setUser(req.getParameter("user_pass"));
		u.setUser(req.getParameter("user_state"));
		u.setUser(req.getParameter("user_pin"));
		u.setUser(req.getParameter("user_gender"));
		Userentity ss = u_dao.user_insert(u);
		if(ss!=null)
		{
			mv.setViewName("user_reg_succ");
		}
		return mv;
	}*/
	
	
	//ADMIN CAN SEE LIST OF SIGN-UP USER'S USING THIS CODE
		@ResponseBody
		@RequestMapping("/user_get")
		public  String[] user_get(HttpServletRequest req, HttpServletResponse res)
		{
			//ModelAndView mv = new ModelAndView();
			List<User> list = u_dao.user_get();
			//mv.setViewName("all_user_list");
			String[] array = new String[list.size()];
			int index = 0;
			for (Object value : list) {
			  array[index] = (String) value;
			  index++;
			}
			return array;
		}		


@ResponseBody
@RequestMapping("/ad_register")
public String Admin_registration(HttpServletRequest req,HttpServletResponse res)
{	
	
	Admin A = new Admin();
	A.setAd_fname(req.getParameter("ad_fname"));
	A.setAd_lname(req.getParameter("ad_lname"));
	A.setAd_pass(req.getParameter("ad_pass"));
	A.setAd_phone(req.getParameter("ad_phone"));
	A.setAd_mail(req.getParameter("ad_mail"));
	A.setAd_coun(req.getParameter("ad_coun"));
	A.setAd_state(req.getParameter("ad_state"));
	A.setAd_dist(req.getParameter("ad_dist"));
	A.setAd_pin(req.getParameter("ad_pin"));
	Admin aa = ad_repo.save(A);
	if(aa!=null)
	{
		return ("Adm-reg-success.jsp");
	}
	return "admin details not entered correctly";

}

@ResponseBody
@RequestMapping("/ad_login")
 public String ad_login(HttpServletRequest req,HttpServletResponse res) {
	 
	 
 // log.info("inside the login ss controller of login request...");
  String ad_fname=req.getParameter("ad_fname");
  String ad_pass=req.getParameter("ad_pass");
    
  if(ad_repo.findbyname(ad_fname)!=null) 
  {
	log.info("verified the credentials...");
	return ("ad_log_sucess.jsp"); 
  }
  return "check the details";
}

//INSERTING PRODUCT CODE
	@ResponseBody
	@RequestMapping("/insert_product")
	public String insert_product(HttpServletRequest req, HttpServletResponse res)
	{
	
		Product p = new Product();
		p.setPro_code(req.getParameter("pro_code"));
		p.setPro_price(req.getParameter("pro_name"));
		p.setPro_brand(req.getParameter("pro_brand"));
		p.setPro_price(req.getParameter("pro_price"));
		p.setPro_about(req.getParameter("pro_about"));
		Product pp = pro_dao.insert_product(p);
		if(pp!=null)
		{
			return ("pro_reg_succ.jsp");
		}
		return "not inserted";
}

} 	  
    	  
    	  
      
	
	
	
	
	
	




